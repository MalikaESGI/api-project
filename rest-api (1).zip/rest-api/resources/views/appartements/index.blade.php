<div id="appartements-disponibles">
</div>

<script>
    fetch('/api/appartements/disponibles')
        .then(response => response.json())
        .then(appartements => {
            const container = document.getElementById('appartements-disponibles');
            appartements.forEach(appartement => {
                const div = document.createElement('div');
                div.innerHTML = `Appartement ID: ${appartement.id} - ${appartement.adresse}`;
                container.appendChild(div);
            });
        });
</script>
