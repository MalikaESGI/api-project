<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Les appartements</title>
</head>

<body>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vos appartements</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap">
    </head>

    <body>





        <div class="card-container">
            @forelse($apartments as $apartment)
                <div class="card">
                    <div class="card-header">
                        <img
                            src="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1471&q=80" />
                    </div>
                    <div class="card-body">
                        <h3> <i class="fa fa-map-marker" aria-hidden="true"></i> {{ $apartment->adresse }}
                        </h3>
                        <p> <i class="fa fa-object-ungroup" aria-hidden="true"></i> {{ $apartment->superficie }} m² <br>
                            <i class="fa fa-money" aria-hidden="true"></i> {{ $apartment->prix_par_nuit }} $

                        </p>
                    </div>
                    <div class="card-footer">
                        <button class="btn"><a
                                href="{{ route('reservations.form', ['appartement_id' => $apartment->id]) }}">tell me
                                more</a></button>
                    </div>
                </div>
            @empty
                <p>Aucun appartement trouvé.</p>
            @endforelse

        </div>


        </div>

        </div>
































        {{-- <div id="app">
            <h1>Vos appartements</h1>

            <div
                class="itemDisplayWrapper col-lg-4 col-md-4 col-sm-6 col-xs-10 col-lg-offset-4 col-md-offset-4 col-sm-offset-3 col-xs-offset-1">
                @forelse($apartments as $apartment)
                    <div class="itemDisplayImg">

                    </div>

                    <div class="itemDisplayDetailLines">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <i class="fa fa-object-ungroup" aria-hidden="true"></i> {{ $apartment->superficie }} m².
                        </div>
                    </div>
                    <div class="itemDisplayDetailLines">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <i class="fa fa-map-marker" aria-hidden="true"></i> {{ $apartment->adresse }}
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <i class="fa fa-money" aria-hidden="true"></i> {{ $apartment->prix_par_nuit }} $
                        </div>
                    </div>
                    <div class="itemDisplayDetailLines">
                        <br>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <a href="{{ route('reservations.form', ['appartement_id' => $apartment->id]) }}"
                                data-toggle="modal" data-target="#modifierModal{{ $apartment->id }}" class="exploreBtn">
                                Reserver
                            </a>
                        </div>
                    </div>
                    <hr>
                @empty
                    <p>Aucun appartement trouvé.</p>
                @endforelse
            </div>
        </div> --}}

        <!-- Add any other scripts or modals you need here -->
    </body>

    </html>



</body>

</html>
<style>
    :root {
        --bg-main: #2b2b2b;
        --bg-accent: #323232;
        --accent: lightslategray;
    }

    body {
        font-family: montserrat, open-sans, sans-serif;
        background-color: var(--bg-main);
        color: #fff;
        line-height: 1.5;
        font-size: 16px;
    }

    h3 {
        font-size: 2rem;
        font-weight: 600;
    }

    img {
        max-inline-size: 100%;
        object-fit: cover;

    }

    /*Cards */

    .card-container {
        padding: 0 1rem;
        counter-reset: card;
    }

    .card {
        margin: 1em 0;
        border-radius: 1rem;
        background: var(--bg-accent);
        box-shadow: -12px 12px 24px #212121,
            12px -12px 24px #353535;
        min-height: 500px;
        display: grid;
        grid-template-rows: 1.5fr 1fr 75px;
        background: linear-gradient(225deg, #2d2d2d, #363636);
    }

    .card-header {
        aspect-ratio: 16/12;
        overflow: hidden;
        border-radius: 1rem 1rem 0 0;
        position: relative;
    }

    .card-header::after {
        counter-increment: card;
        /* Increment the value of the counter by 1 */
        content: "0" counter(card);
        position: absolute;
        inset: auto 0 0 auto;
        margin-bottom: .5em;
        font-size: 6em;
        color: var(--accent);
        font-weight: 800;
        opacity: .75;

    }

    .card img {
        min-height: 100%;

    }

    .card-body,
    .card-footer {
        padding: 0 1rem;
    }

    .card-footer {
        display: grid;
        align-items: center;


    }

    .card h3 {
        margin: 0;
        position: relative;
    }

    .card-body p {
        font-weight: 200;
        font-size: 1rem;
        margin: 0;
    }

    @media only screen and (min-width: 400px) {

        .card-container {
            display: grid;
            justify-content: center;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
            max-width: 92%;
            margin: 0 auto;


        }


        .card h3 {
            margin: 1em 0 .25em 0;
            position: relative;
        }

        .card-header::after {
            margin-bottom: 0em;
        }

    }


    @media only screen and (min-width: 900px) {

        .card-container {

            max-width: 85%;
            gap: 2rem;


        }



    }

    .btn {
        font-weight: regular;
        border-radius: .5rem;
        padding: 14px 20px;
        font-size: 13px;
        outline: none;
        max-width: 42%;
        cursor: pointer;
        text-align: center;
        display: inline-block;
        transition: all .3s;
        background-color: transparent;
        border: 1px solid var(--accent);
        color: var(--accent);
    }
</style>
