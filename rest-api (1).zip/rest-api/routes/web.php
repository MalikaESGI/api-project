<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;


use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ProprietaireController;
use App\Http\Controllers\Api\ClientController;
use App\Http\Controllers\InternController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Api\AppartementsController;
use App\Models\Appartements;
use App\Models\Client;
use App\Models\Proprietaire;

Route::get('/login', [UserController::class, 'showLoginForm'])->name('login.form');
Route::post('/login', [UserController::class, 'login'])->name('login.process');

Route::get('/proprietaire/appartements', [ProprietaireController::class, 'showApartments'])->name('proprietaire.appartements');
Route::get('/modify_disponibilite/{id}', [ProprietaireController::class, 'showModifyDisponibiliteForm'])->name('show_modify_disponibilite_form');
Route::put('/modify_disponibilite/{id}', [ProprietaireController::class, 'modifyDisponibilite'])->name('modify_disponibilite');

Route::get('/client/appartements', [ClientController::class, 'listAvailableAppartements'])->name('client.appartements');
Route::get('/client/reservation/{appartement_id}', [ClientController::class, 'showReservationForm'])->name('reservations.form');
Route::post('/client/reservation', [ClientController::class, 'makeReservation'])->name('client.reservation.process');
Route::get('/intern/dashboard', [InternController::class, 'dashboard'])->name('intern.dashboard');
Route::get('/intern/clients', [InternController::class, 'showClients'])->name('intern.clients.show');
Route::get('/intern/client/delete', [ClientController::class, 'delete'])->name('client.delete');
Route::get('/intern/landlords/delete', [ProprietaireController::class, 'delete'])->name('landlord.delete');
Route::get('/intern/Landlords', [InternController::class, 'showLandlords'])->name('intern.landlords.show');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/intern/appartements', [AppartementsController::class, 'index'])->name('intern.appartements');
Route::get('/apartments/{apartment}/edit', [AppartementsController::class, 'edit'])->name('appartement.edit.form');
Route::put('/apartments/{apartment}', [AppartementsController::class, 'update'])->name('apartments.update');
Route::get('/apartments/create', [AppartementsController::class, 'create'])->name('apartments.create');
Route::post('/apartments/store', [AppartementsController::class, 'store'])->name('apartments.store');
