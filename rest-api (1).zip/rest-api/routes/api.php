<?php

use App\Http\Controllers\Api\AppartementsController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ProprietaireController;
use App\Http\Controllers\Api\ClientController;
use Illuminate\Support\Facades\Route;


Route::resource('appartements', AppartementsController::class)->except(['create', 'edit']);

Route::get('register', [UserController::class, 'showRegisterForm'])->name('register.form');
Route::post('register', [UserController::class, 'register'])->name('register.process');

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/sanctum-test', function () {
        return response()->json(['message' => 'Authenticated via Sanctum']);
    });
});
Route::middleware('auth:api')->group(function () {
    Route::get('/appartements/disponibles', [ClientController::class, 'listAvailableAppartements']);
    Route::post('/reservations', [ClientController::class, 'makeReservation']);
});
