<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * APPARTEMENTS:
     *   - id (clé primaire)
     *   - superficie
     *   - capacite
     *   - adresse
     *   - disponibilite
     *   - prix_par_nuit
     *   - id_proprietaire (clé étrangère référençant la table users)
     */
    public function up(): void
    {
        Schema::create('appartements', function (Blueprint $table) {
            $table->id();
            $table->float('superficie');
            $table->integer('capacite');
            $table->string('adresse');
            $table->boolean('disponibilite')->default(true);
            $table->decimal('prix_par_nuit', 10, 2);
            $table->bigInteger('id_proprietaire')->unsigned(); // Foreign key for owner's ID
            $table->timestamps();

            // Foreign key constraint
            $table->foreign('id_proprietaire')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('appartements');
    }
};
