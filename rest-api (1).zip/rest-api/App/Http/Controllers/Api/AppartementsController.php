<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Appartements;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\CreateAppartementsRequest;
use App\Http\Requests\EditAppartementsRequest;
use Illuminate\Support\Facades\View;
use Exception;

class AppartementsController extends Controller
{
    public function create()
    {
        $proprietaires = User::where('role', 'proprietaire')->get();

        return view('intern.appartement_create', compact('proprietaires'));
    }



    public function index(Request $request)
    {
        try {
            $query = Appartements::query();
            $perPage = 10;
            $page = $request->input('page', 1);
            $search = $request->input('search');

            $total = $query->count();
            $result = $query->offset(($page - 1) * $perPage)->limit($perPage)->get();

            // Vous pouvez passer les données nécessaires à la vue ici
            $data = [
                'status_code' => 200,
                'status_message' => 'Appartements Récuperé',
                'current_page' => $page,
                'last_page' => ceil($total / $perPage),
                'items' => $result
            ];

            // Rediriger vers la vue avec les données
            return View::make('intern.appartements', $data);
        } catch (Exception $e) {
            return response()->json($e);
        }
    }

    public function edit(Appartements $apartment)
    {
        return view('intern.appartement_update', compact('apartment'));
    }

    public function store(CreateAppartementsRequest $request)
    {
        try {
            $appartements = new Appartements();

            $appartements->superficie = $request->superficie;
            $appartements->capacite    = $request->capacite;
            $appartements->adresse = $request->adresse;
            $appartements->disponibilite = $request->disponibilite;
            $appartements->prix_par_nuit = $request->prix_par_nuit;
            $appartements->id_proprietaire = $request->id_proprietaire;

            $appartements->save();

            return response()->json([
                'status_code' => 200,
                'status_message' => 'Le post a ete ajoute',
                'data' => $appartements
            ]);
        } catch (Exception $e) {
            return response()->json($e);
        }
    }

    public function update(EditAppartementsRequest $request, $id)
    {

        $appartements = Appartements::find($id);

        $appartements->superficie = $request->superficie;
        $appartements->capacite    = $request->capacite;
        $appartements->adresse = $request->adresse;
        $appartements->disponibilite = $request->disponibilite;
        $appartements->prix_par_nuit = $request->prix_par_nuit;
        $appartements->id_proprietaire = $request->id_proprietaire;

        $appartements->save();

        return response()->json([
            'status_code' => 200,
            'status_message' => 'Le bien a ete modifié',
            'data' => $appartements
        ]);
    }

    public function delete($id)
    {
        try {
            $appartement = Appartements::find($id);

            if (!$appartement) {
                return response()->json([
                    'status_code' => 404,
                    'status_message' => 'Appartement non trouvé',
                ], 404);
            }

            $appartement->delete();

            return response()->json([
                'status_code' => 200,
                'status_message' => 'Appartement supprimé',
                'data' => $appartement,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status_code' => 500,
                'status_message' => 'Erreur lors de la suppression de l\'appartement',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
