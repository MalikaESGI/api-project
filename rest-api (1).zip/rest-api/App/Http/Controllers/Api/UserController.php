<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterUser;
use App\Http\Requests\LogUserRequest;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;



class UserController extends Controller
{
    public function showRegisterForm()
    {
        return view('register');
    }
    public function register(RegisterUser $request)
    {
        try {
            $user = new User();

            $user->nom = $request->nom;
            $user->prenom = $request->prenom;
            $user->email = $request->email;
            $user->password = Hash::make($request->password, [
                'rounds' => 12
            ]);

            $user->role = 'client';

            $user->save();
            return response()->json([
                'status_code' => 200,
                'status_message' => 'Inscription Faite',

            ]);
            Auth::login($user);
        } catch (Exception $e) {
            return response()->json($e);
        }
    }


    public function showLoginForm()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $user = Auth::user();

            if ($user->role === 'client') {
                return redirect()->route('client.appartements');
            } elseif ($user->role === 'proprietaire') {
                return redirect()->route('proprietaire.appartements');
            } else {
                // Handle other roles or redirect to a default route
                return redirect()->route('intern.dashboard');
            }
        }

        return back()->withErrors(['email' => 'Invalid credentials']);
    }
}
