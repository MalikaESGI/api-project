<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\ModifyDisponibiliteRequest;
use App\Models\Appartements;
use App\Models\Proprietaire;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProprietaireController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function showApartments()
    {
        if (Auth::check()) {
            $userId = Auth::id();

            $appartements = Appartements::where('id_proprietaire', $userId)->get();

            return view('proprietaire.appartements', [
                'user_id' => $userId,
                'apartments' => $appartements,
            ]);
        }

        return response()->json([
            'status_code' => 403,
            'status_message' => 'User not authenticated.',
        ], 403);
    }


    public function showModifyDisponibiliteForm($id)
    {
        $apartment = Appartements::findOrFail($id);

        if (Auth::id() !== $apartment->id_proprietaire) {
            abort(403, 'Unauthorized action.');
        }

        return view('proprietaire.modify', ['apartment' => $apartment]);
    }

    public function modifyDisponibilite($id, ModifyDisponibiliteRequest $request)
    {
        $apartment = Appartements::findOrFail($id);
        $apartment->update([
            'disponibilite' => $request->input('disponibilite'),
        ]);

        return redirect()->back()->with('status', 'Disponibilité modifiée avec succès.');
    }

    public function delete(Proprietaire $proprietaire)
    {
        $proprietaire->delete();
        return redirect()->route('client.index');
    }
}
