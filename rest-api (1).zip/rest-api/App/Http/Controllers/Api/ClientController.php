<?php

namespace App\Http\Controllers\Api;

use Carbon\Carbon;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateReservationRequest;
use App\Models\Appartements;
use App\Models\Reservation;
use App\Model\Client;
use App\Models\Client as ModelsClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClientController extends Controller
{
    public function listAvailableAppartements(Request $request)
    {
        $appartements = Appartements::where('disponibilite', true)->get();
        return view('reservations.appartements', [
            'apartments' => $appartements,
        ]);


        return response()->json($appartements);
    }

    public function showReservationForm($appartement_id)
    {
        $appartement = Appartements::find($appartement_id);
        return view('reservations.form', compact('appartement'));
    }

    public function makeReservation(CreateReservationRequest $request)
    {
        $date_debut = Carbon::parse($request->date_debut)->format('Y-m-d');
        $date_fin = Carbon::parse($request->date_fin)->format('Y-m-d');
        $reservation = Reservation::create([
            'user_id' => Auth::id(),
            'appartement_id' => $request->appartement_id,
            'date_debut' => $date_debut,
            'date_fin' => $date_fin,
        ]);

        return response()->json($reservation, 201);
    }

    public function delete(ModelsClient $client)
    {
        $client->delete();
        return redirect()->route('client.index');
    }
}
