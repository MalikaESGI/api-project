<?php

namespace App\Http\Controllers;

use App\Models\Intern;
use App\Models\User;
use Illuminate\Http\Request;

class InternController extends Controller
{

    public function dashboard()
    {
        return view('intern.dashboard');
    }

    public function showClients()
    {
        $clients = User::where('role', 'client')->get();
        return view('intern.clients', compact('clients'));
    }
    public function showLandlords()
    {
        $proprietaires = User::where('role', 'proprietaire')->get();
        return view('intern.landlords', compact('proprietaires'));
    }
}
