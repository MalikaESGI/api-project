<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Models\Reservation;

class CreateReservationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'appartement_id' => 'required|exists:appartements,id',
            'date_debut' => [
                'required',
                'date',
                'after:today',
                Rule::unique('reservations')->where(function ($query) {
                    return $query->where('appartement_id', $this->input('appartement_id'))
                        ->where(function ($query) {
                            $query->where('date_debut', '<=', $this->input('date_fin'))
                                ->where('date_fin', '>=', $this->input('date_debut'));
                        });
                }),
            ],
            'date_fin' => [
                'required',
                'date',
                'after:date_debut',
            ],
        ];
    }

    public function messages()
    {
        return [
            'date_debut.unique' => 'Indisponible à ces dates. Prochaine disponibilités: ' . $this->getNextAvailableDate(),
        ];
    }

    private function getNextAvailableDate()
    {
        $appartementId = $this->input('appartement_id');
        $lastReservation = Reservation::where('appartement_id', $appartementId)
            ->where('date_fin', '>=', $this->input('date_fin'))
            ->orderBy('date_fin', 'asc')
            ->first();

        if ($lastReservation) {
            $nextAvailableDate = date('Y-m-d', strtotime($lastReservation->date_fin . ' + 1 day'));
        } else {
            $nextAvailableDate = date('Y-m-d', strtotime($this->input('date_fin') . ' + 1 day'));
        }

        return $nextAvailableDate;
    }
}
