<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class EditAppartementsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [

            'superficie' => 'required',
            'capacite' => 'required',
            'adresse' => 'required',
            'disponibilite' => 'required',
            'prix_par_nuit' => 'required',
            'id_proprietaire' => 'required',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'success' => false,
            'error' => true,
            'message' => 'Erreur de validation',
            'errorsList' => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'superficie.required' => 'Une superficie doit etre renseigner',
            'capacite.required' => 'Une capacite doit etre renseigner',
            'adresse.required' => 'Une adresse doit etre renseigner',
            'disponibilite.required' => 'La disponibilité doit etre renseigner',
            'prix_par_nuit.required' => 'Le prix doit etre renseigner',
            'id_proprietaire.required' => 'Le propriétaire doit etre renseigner',
        ];
    }
}
