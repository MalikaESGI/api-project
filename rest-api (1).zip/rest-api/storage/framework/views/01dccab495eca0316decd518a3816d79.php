<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservation</title>
</head>

<body>
    <div class="panel">

        <div class="left">

            <h1>WELCOME</h1>

            <h2>to the Rest-API reservation</h2>

        </div>

        <div class="right">

            <h3>Resrvation en ligne</h3>

            <form method="POST" action="<?php echo e(route('client.reservation.process')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="appartement_id" value="<?php echo e($appartement->id); ?>">

                <h4>Arrival Date:<h4>
                        <p><input type="date" name="date_debut" class="form-control" required>
                        </p>
                        <h4>Departure Date:</h4>
                        <p><input type="date" name="date_fin" class="form-control" required>
                        </p>
                        <h4>Address</h4>
                        <p><?php echo e($appartement->adresse); ?></p>
                        <button type="submit">Reserver</button>
            </form>
            <?php if($errors->any()): ?>
                <div style="color: red;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Spectral&display=swap");

        * {
            box-sizing: border-box;
        }

        body {
            font-family: "Spectral", serif;

            display: flex;

            align-items: center;

            justify-content: center;

            min-height: 100vh;

            margin: 0;

            color: rgb(255, 255, 255);
        }

        body::after {
            background-image: url("https://i.pinimg.com/550x/44/17/44/441744242a11988485a786f09d39f6af.jpg");

            background-repeat: no-repeat;

            background-size: cover;

            background-position: center center;

            content: "";

            filter: blur(5px);

            position: absolute;

            top: 0px;

            left: 0px;

            height: 100vh;

            width: 100vw;

            z-index: -1;
        }

        .panel {
            display: flex;

            min-height: 70vh;

            min-width: 70vw;

            max-width: 800px;
        }

        .right {
            color: #3f1352;

            flex-direction: column;

            padding: 25px;

            position: relative;

            width: 400px;

            background-color: #fff;

            max-height: 500px;

            border-radius: 25px;

            opacity: 0.9;
        }

        .right h3 {
            margin: 0;
            text-transform: uppercase;
            color: #371047;
        }

        .right h4 {
            border-bottom: 1px solid #333;
        }

        .right p {
            color: #192d3c;

            font-weight: 500;

            font-size: 1.2rem;

            margin: 13px 0;
            margin-top: -20px;
        }

        .right button {
            background-color: #3f1352;

            border: 1px solid #8e44ad;

            color: #d2b9a0;
            font-weight: bold;

            cursor: pointer;

            font-weight: 500;

            padding: 15px 30px;

            margin-top: auto;
        }

        .left {
            width: calc(80% + 50px);
        }

        h1 {
            font-size: 5.25rem;

            color: #fff;

            position: relative;

            top: 100px;
            text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000,
                1px 1px 0 #000;
            text-transform: uppercase;
        }

        h2 {
            font-size: 2rem;

            color: #fff;
            text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000,
                1px 1px 0 #000;

            position: relative;

            top: 50px;

            left: 60px;
            text-transform: uppercase;
        }
    </style>


</body>

</html>
<?php /**PATH D:\XAMP\htdocs\rest-api_2\rest-api\rest-api\resources\views/reservations/form.blade.php ENDPATH**/ ?>