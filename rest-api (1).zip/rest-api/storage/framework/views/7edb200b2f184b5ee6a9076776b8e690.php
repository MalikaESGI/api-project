<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la disponibilité</title>
</head>

<body>
    <div>
        <fieldset>
            <p>Update Form</p>
            <label>Superficie:<?php echo e($apartment->superficie); ?> </label><br>
            <label>Capacite:<?php echo e($apartment->capacite); ?></label><br>
            <label>Superficie:<?php echo e($apartment->superficie); ?></label><br>
            <label>Adresse:<?php echo e($apartment->adresse); ?></label><br>
            <label>Prix:<?php echo e($apartment->prix_par_nuit); ?></label><br>



            <form action="<?php echo e(route('modify_disponibilite', ['id' => $apartment->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <label for="disponibilite">Disponibilité :</label>
                <select name="disponibilite" id="disponibilite">
                    <option value="1" <?php if($apartment->disponibilite == '1'): ?> selected <?php endif; ?>>Oui</option>
                    <option value="0" <?php if($apartment->disponibilite == '0'): ?> selected <?php endif; ?>>Non</option>
                </select>

                <button type="submit">Enregistrer</button>
                <a href="<?php echo e(route('proprietaire.appartements')); ?>">Retour a mes appartements</a>

            </form>

        </fieldset>
    </div>

</body>

</html>
<style>
    :root {
        --bg-color: beige;
        --focus-color: #857E61;
        /* Reseda Green */
        --btn-color: #DBFCFF;
        /* Light Cyan */
        --btn-hover-color: #5995ED
            /* Cornflower Blue */
    }

    body {
        height: 100vh;
        overflow: hidden;
    }

    p {
        margin-left: 2%;
        font-size: 20pt;
    }

    p:hover {
        cursor: pointer;
        font-size: 22pt;
        color: var(--focus-color);
    }

    fieldset,
    form {
        background-color: var(--bg-color);
        font-weight: bold;
        font-size: 18px;
        height: 80vh;
        line-height: 100%;
        padding: 0;
        margin: 3em;
        overflow: hidden;
    }

    form label.fixdw {
        float: left;
        width: 240px;
        margin-top: 5px;
    }

    input,
    textarea {
        margin: 8px 0;
        resize: none;
    }

    input[type=text],
    input[type=email],
    textarea {
        width: 12%;
        padding: 10px 10px;
        transition: all 0.2s ease-in-out;
    }

    input[type=text]:focus,
    input[type=email]:focus {
        width: 20%;
        outline: 2px solid var(--focus-color);
    }

    textarea:focus {
        height: 15%;
        width: 20%;
        outline: 2px solid var(--focus-color);
    }

    input[type=radio] {
        accent-color: var(--focus-color);
    }

    button[type=submit],
    button[type=reset] {
        cursor: pointer;
        background-color: var(--btn-color);
        font-weight: bold;
        padding: 5px 10px;
    }

    button[type=submit]:hover,
    button[type=reset]:hover {
        background-color: var(--btn-hover-color);
        color: #fff;
        transform: scale(1.1);
    }
</style>
<?php /**PATH D:\XAMP\htdocs\rest-api_2\rest-api\rest-api\resources\views/proprietaire/modify.blade.php ENDPATH**/ ?>