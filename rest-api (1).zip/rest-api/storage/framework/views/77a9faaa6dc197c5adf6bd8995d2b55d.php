<!-- resources/views/proprietaire/modify_disponibilite.blade.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la disponibilité</title>
</head>

<body>
    <h2>Modifier la disponibilité</h2>

    <form action="<?php echo e(route('modify_disponibilite', ['id' => $apartment->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <label for="disponibilite">Disponibilité :</label>
        <select name="disponibilite" id="disponibilite">
            <option value="1" <?php if($apartment->disponibilite == '1'): ?> selected <?php endif; ?>>Oui</option>
            <option value="0" <?php if($apartment->disponibilite == '0'): ?> selected <?php endif; ?>>Non</option>
        </select>

        <button type="submit">Enregistrer</button>
    </form>

    <a href="<?php echo e(route('proprietaire.appartements')); ?>">Retour a mes appartements</a>

</body>

</html>
<?php /**PATH D:\XAMP\htdocs\REST-API\rest-api\resources\views/proprietaire/modify.blade.php ENDPATH**/ ?>