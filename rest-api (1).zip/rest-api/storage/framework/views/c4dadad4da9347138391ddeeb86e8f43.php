<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ajout</title>
</head>

<body>
    <div>
        <fieldset>
            <p>Create Form</p>

            <form action="<?php echo e(route('apartments.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Superficie -->
                <label for="superficie">Superficie:</label>
                <input type="text" name="superficie" required>

                <!-- Capacite -->
                <label for="capacite">Capacite:</label>
                <input type="text" name="capacite" required>

                <!-- Disponibilite -->
                <label for="disponibilite">Disponibilite:</label>
                <select name="disponibilite" required>
                    <option value="1">Disponible</option>
                    <option value="0">Indisponible</option>
                </select>

                <!-- Adresse -->
                <label for="adresse">Adresse:</label>
                <input type="text" name="adresse" required>

                <!-- Prix -->
                <label for="prix_par_nuit">Prix:</label>
                <input type="text" name="prix_par_nuit" required>

                <!-- Proprietaire Dropdown -->
                <label for="id_proprietaire">Proprietaire:</label>
                <select name="id_proprietaire" required>
                    <?php $__currentLoopData = $proprietaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proprietaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($proprietaire->id); ?>"><?php echo e($proprietaire->email); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Submit Button -->
                <div class="btn-group">
                    <button type="submit">Submit</button>
                </div>
            </form>
        </fieldset>
    </div>

</body>

</html>
<style>
    :root {
        --bg-color: beige;
        --focus-color: #857E61;
        /* Reseda Green */
        --btn-color: #DBFCFF;
        /* Light Cyan */
        --btn-hover-color: #5995ED
            /* Cornflower Blue */
    }

    body {
        height: 100vh;
        overflow: hidden;
    }

    p {
        margin-left: 2%;
        font-size: 20pt;
    }

    p:hover {
        cursor: pointer;
        font-size: 22pt;
        color: var(--focus-color);
    }

    fieldset,
    form {
        background-color: var(--bg-color);
        font-weight: bold;
        font-size: 18px;
        height: 80vh;
        line-height: 100%;
        padding: 0;
        margin: 3em;
        overflow: hidden;
    }

    form label.fixdw {
        float: left;
        width: 240px;
        margin-top: 5px;
    }

    input,
    textarea {
        margin: 8px 0;
        resize: none;
    }

    input[type=text],
    input[type=email],
    textarea {
        width: 12%;
        padding: 10px 10px;
        transition: all 0.2s ease-in-out;
    }

    input[type=text]:focus,
    input[type=email]:focus {
        width: 20%;
        outline: 2px solid var(--focus-color);
    }

    textarea:focus {
        height: 15%;
        width: 20%;
        outline: 2px solid var(--focus-color);
    }

    input[type=radio] {
        accent-color: var(--focus-color);
    }

    button[type=submit],
    button[type=reset] {
        cursor: pointer;
        background-color: var(--btn-color);
        font-weight: bold;
        padding: 5px 10px;
    }

    button[type=submit]:hover,
    button[type=reset]:hover {
        background-color: var(--btn-hover-color);
        color: #fff;
        transform: scale(1.1);
    }
</style>
<?php /**PATH D:\XAMP\htdocs\rest-api_2\rest-api\rest-api\resources\views/intern/appartement_create.blade.php ENDPATH**/ ?>