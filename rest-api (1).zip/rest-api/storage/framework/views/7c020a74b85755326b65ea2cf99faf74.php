<!-- resources/views/proprietaire/appartements.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vos appartements</title>
</head>

<body>
    <div id="app">
        <h1>Vos appartements</h1>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap">

        <?php $__empty_1 = true; $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="product-card">
                <div class="product-img-container">
                    <div class="product-img"></div>
                </div>
                <div class="product-info">
                    <h2 class="product-title"><strong><?php echo e($apartment->adresse); ?></strong></h2>
                    <p class="product-price"><strong>Superficie : </strong><?php echo e($apartment->superficie); ?> m²<br>
                        <strong> Prix : </strong><?php echo e($apartment->prix_par_nuit); ?> $<br>
                        <strong>Disponibilité :</strong>
                        <?php if($apartment->disponibilite == '1'): ?>
                            Oui
                        <?php else: ?>
                            Non
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(route('show_modify_disponibilite_form', ['id' => $apartment->id])); ?>"
                        data-toggle="modal" data-target="#modifierModal<?php echo e($apartment->id); ?>">
                        Modifier
                    </a>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>
                        <p>Aucun appartement trouvé.</p>
                    </li>
        <?php endif; ?>

    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/vue@2"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
        new Vue({
            el: '#app',
            data: {
                user_id: null,
                apartments: [],
            },
            mounted() {
                axios.get('/api/proprietaire/appartements')
                    .then(response => {
                        this.user_id = response.data.user_id;
                        this.apartments = response.data.apartments;
                    })
                    .catch(error => console.error('Erreur lors de la récupération des données :', error));
            }
        });
    </script>
</body>

</html>
<style>
    body {
        font-family: 'Montserrat', sans-serif;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background-color: #f0f0f0;
    }

    .product-card {
        width: 400px;
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
        overflow: hidden;
    }

    .product-img-container {
        width: 100%;
        position: relative;
        overflow: hidden;
    }

    .product-img {
        width: 100%;
        height: 300px;
        background-image: url('https://freepngimg.com/save/28530-nike-shoes-transparent/1464x1533');
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
    }

    .product-info {
        padding: 20px;
    }

    .product-title {
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 10px;
    }

    .product-description {
        font-size: 16px;
        margin-bottom: 20px;
    }

    .product-price {
        font-size: 20px;
        font-weight: 700;
    }

    .icon-container {
        display: flex;
        justify-content: left;
        align-items: flex-start;
        gap: 10px;
    }

    .icon-container i {
        font-size: 24px;
        cursor: pointer;
        transition: color 0.3s ease-in-out;
    }

    .fa-heart {
        color: white;
        -webkit-text-stroke-width: 2px;
        -webkit-text-stroke-color: black;
        transition: all 0.4s ease;
    }

    .fa-heart.full {
        color: #000;
    }

    .cart-icon {
        font-size: 24px;
        cursor: pointer;
    }
</style>
<?php /**PATH D:\XAMP\htdocs\rest-api_2\rest-api\rest-api\resources\views/proprietaire/appartements.blade.php ENDPATH**/ ?>